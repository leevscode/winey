import styled from "@emotion/styled";

export const AdminWrap = styled.div`
  font-size: 1.6rem;
  background: pink;
`;
