import React from "react";

const CountryWine = () => {
  return <div>CountryWine</div>;
};

export default CountryWine;
