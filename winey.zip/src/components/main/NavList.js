import React from "react";

const NavList = () => {
  return <div>NavList</div>;
};

export default NavList;
