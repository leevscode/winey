import React from "react";

const WineGuide = () => {
  return <div>WineGuide</div>;
};

export default WineGuide;
