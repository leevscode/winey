import React from "react";

const AdminHome = () => {
  return <div>어드민 홈</div>;
};

export default AdminHome;
