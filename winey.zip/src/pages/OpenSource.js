import React from "react";

const OpenSource = () => {
  return <div>오픈소스</div>;
};

export default OpenSource;
