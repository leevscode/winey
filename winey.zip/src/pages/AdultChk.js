import React from "react";

const AdultChk = () => {
  return <div>AdultChk</div>;
};

export default AdultChk;
