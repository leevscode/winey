import React from "react";

const About = () => {
  return <div>만든 사람들</div>;
};

export default About;
