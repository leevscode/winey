import React from "react";

const ProductSell = () => {
  return <div>ProductSell</div>;
};

export default ProductSell;
