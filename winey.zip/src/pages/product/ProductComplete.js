import React from "react";

const ProductComplete = () => {
  return <div>ProductComplete</div>;
};

export default ProductComplete;
