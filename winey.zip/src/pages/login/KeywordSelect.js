/*
    작업자 : 최혜미
    노션 : https://hyemdev.notion.site/hyemdev/hyem-s-dev-STUDY-75ffe819c7534a049b59871e6fe17dd4
    깃허브 : https://github.com/hyemdev
*/

import React from "react";
import Welcome from "../../components/join/Welcome";
import KeywordChooseCp from "../../components/join/KeywordChooseCp";

const KeywordSelect = () => {
  return (
    <div>
      <KeywordChooseCp />
    </div>
  );
};

export default KeywordSelect;
